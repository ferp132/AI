#include <iostream>

#include "Board.h"
#include "Game.h"

using namespace std;

int main() {

	Game MainGame;
	MainGame.GameLoop();
	int i;
	cin >> i;
	return 0;
}

