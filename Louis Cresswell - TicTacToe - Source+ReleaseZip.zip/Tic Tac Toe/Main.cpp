#include <iostream>

#include "Board.h"
#include "Game.h"

using namespace std;

int main() {

	Game MainGame;
	while (true)
	{
		MainGame.GameLoop();
		int i;
		cout << "Press Enter to Restart";
		cin >> i;
	}
	return 0;
}

