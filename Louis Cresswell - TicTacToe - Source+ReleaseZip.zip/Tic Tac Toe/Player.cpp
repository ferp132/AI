#include "Player.h"

Player::Player()
{
}

Player::~Player()
{
}

void Player::PickTile()
{
	int Choice;
	cout << "Pick A Tile: ";
	cin >> Choice;


}
